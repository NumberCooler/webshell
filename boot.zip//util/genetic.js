

function Sex(mutateProb) {
    this.mutateProb = mutateProb;
    this.events = Class.create("WithEvents");
}
Sex.prototype.make = async function(A,B) {
    var newborn = { value : null };
    await this.events.emit("transfer",[A,B,newborn]);
    if (Math.random() <= this.mutateProb) {
        newborn.value = await this.mutate(newborn.value);
    }
    return newborn.value;
}
Sex.prototype.mutate = async function(A) { // no mutations
    return A;
}
function Population(last_saved_population,test) {
    this.population = last_saved_population;
    this.test = test; // set .fitness of each individual
}
Population.prototype.remix = async function(sex,kill,threshold_fitness,timespan_limit) {
    await this.test(this.population); 
    this.population.sort((a,b)=> { return a.fitness > b.fitness; });
    let breeders = Math.round((1-kill)*this.population.length);
    let newPopulation = this.population.slice(0, breeders);
    var timespan_cur = 0;
    var babies = [];
    while (timespan_cur < timespan_limit && newPopulation.length < 2*this.population) {
        let parentAIndex = Math.floor(Math.random() * breeders);
        let parentBIndex = Math.floor(Math.random() * breeders);
        while (parentAIndex == parentBIndex) parentBIndex = Math.floor(Math.random() * breeders);
        let parentA = population[parentAIndex];
        let parentB = population[parentBIndex];
        let newborn = await sex.make(parentA, parentB);
        var newbordcase = [newborn];
        await this.test(newborncase);
        if( newbordcase[0].fitness > threshold_fitness ) {
            newPopulation.push(newborn);
            babies.push(newborn);
        }
        timespan_cur++;
    }
    return {
        oldpopulation : this.population,
        newpopulation : newPopulation,
        babies
    };
}

app.saveText("genetic2.js",app.editor.getValue());