/*
    teste2
*/

var m = await app.loadSuper("a.super");
m("hello world","world 12345","a.out","b.out");