var factory = await app.loadSuper("/apps/worker.super");
function genThread(k) {
    const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
    return factory(new AsyncFunction('buffer',`
        var self = this;
        console.log(buffer[0].loc);
        const ta = new Uint32Array(buffer[0].sab);
        return await new Promise((resolve,reject)=>{
            function do1(x) {
                if(x>1000) {
                    resolve(`+k+`);
                } else {
                    Atomics.store(ta,buffer[0].loc,x);
                    setTimeout(()=>{
                        do1(x+1);
                    },0);
                }
            }
            do1(0);
        });
        
    `));
}
var worker1 = genThread(1);
var worker2 = genThread(2);
var worker3 = genThread(3);
var worker4 = genThread(4);

var sab = new SharedArrayBuffer(1024);

var check1 = {loc:1,sab};
var check2 = {loc:2,sab};
var check3 = {loc:3,sab};
var check4 = {loc:4,sab};

var val1 = worker1.run(check1);
var val2 = worker2.run(check2);
var val3 = worker3.run(check3);
var val4 = worker4.run(check4);

var ta = new Uint32Array(sab);

var loop = setInterval(()=>{
    var a1 = Atomics.load(ta,1);
    var a2 = Atomics.load(ta,2);
    var a3 = Atomics.load(ta,3);
    var a4 = Atomics.load(ta,4);
    console.log("state:",a1,a2,a3,a4);
},100);


var data = await Promise.all([val1,val2,val3,val4]);
console.log("results:",data);

clearInterval(loop);


var label = await app.loadSuper("/apps/test.super");
setTimeout(()=>{
    label.$.elementSetPacketAsync(`loaded`);
},3000);

