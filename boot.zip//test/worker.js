var factory = await app.loadSuper("/apps/worker.super");
function genThread(k) {
    const AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
    return factory(new AsyncFunction('buffer',`
        var self = this;
        console.log(buffer[0].loc);
        const ta = new Uint32Array(buffer[0].sab);
        return await new Promise((resolve,reject)=>{
            function do1(x) {
                if(x>100) {
                //if(x>1000) {
                    resolve(`+k+`);
                } else {
                    Atomics.store(ta,buffer[0].loc,x);
                    //for(var y = 0;y < 1000;y++) ;
                    for(var y = 0;y < 100000000;y++) ;
                    setTimeout(()=>{
                        do1(x+1);
                    },0);
                }
            }
            do1(0);
        });
        
    `));
}

var sab = new SharedArrayBuffer(1024);
var ta = new Uint32Array(sab);
var workers = [];
var CPUS = 4;

function newJob(x) {
    return {
        instance : genThread(x),
        args : { loc : (x+1), sab }
    }
}
for(var x = 0; x < CPUS;x++) {
    var job = newJob(x);
    workers.push(job);
    job.value = job.instance.run(job.args);
}
function close() {
    for(var x = 0; x < workers.length;x++) {
        workers[x].instance.close();
    }
}
var loop = setInterval(()=>{
    var arr = [];
    for(var x = 0; x < CPUS;x++) arr.push(Atomics.load(ta,x+1));
    console.log("state:",arr);
},100);

var data = await Promise.all(workers.map((a)=>{ return a.value; }));
console.log("results:",data);

close();

clearInterval(loop);

var label = await app.loadSuper("/apps/test.super");
setTimeout(()=>{
    label.$.elementSetPacketAsync(`loaded`);
},3000);

